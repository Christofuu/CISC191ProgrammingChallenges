package cisc191.sdmesa.edu;

import java.awt.Color;

/**
 * Lead Author(s): 
 * @author Christopher Dove
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here>>
 *  
 * Version/date: 9/14/22
 * 
 * Responsibilities of class:
 * 
 */

//TODO: implement and remove all TODOs

/**
 */
public class Boat
{
	// TODO: Implement and comment all HAS-A relationships separately
	// For instance: A boat has a make
	private String make;
	private Color color;
	private int speed = 0;
	private int price = -1;
	
	Boat()
	{
		
	}
	
	Boat(String make, Color color)
	{
		this.make = make;
		this.color = color;
	}
	
	Boat(Boat boat)
	{
		this.make = boat.make;
		this.color = boat.color;
		this.price = boat.price;
		this.speed = boat.speed;
	}
	/**
	 * Purpose: // TODO
	 * @return // TODO
	 */
	public String getMake()
	{
		// TODO
		return make;
	}

	/**
	 * Purpose: // TODO
	 * @return // TODO
	 */
	public Color getColor()
	{
		// TODO
		return color;
	}

	/**
	 * Purpose: // TODO
	 * @return // TODO
	 */
	public int getSpeed()
	{
		// TODO
		return speed;
	}
	
	public int getPrice()
	{
		return price;
	}
	
	public void setPrice(int price) 
	{
		if (price > 0) 
		{
			this.price = price;
		}
	}
	
	public void setColor(Color color)
	{
		this.color = color;
	}
	
	public void speedUp()
	{
		++this.speed;
	}
	
	public void slowDown()
	{
		--this.speed;
	}
}
